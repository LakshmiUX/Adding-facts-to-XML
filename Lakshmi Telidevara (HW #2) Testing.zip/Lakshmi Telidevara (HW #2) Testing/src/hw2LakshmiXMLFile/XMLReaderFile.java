package hw2LakshmiXMLFile;
import javax.xml.transform.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


public class XMLReaderFile 
{
	
	private static Fact getfact(Node node) {
        // XMLReaderDOM domReader = new XMLReaderDOM();
        Fact fact = new Fact();
        if (node.getNodeType() == Node.ELEMENT_NODE) {
            Element element = (Element) node;
            
            fact.setFactText(getTagValue("fact-text", element));
            fact.setAuthor(getTagValue("author", element));
            fact.setFactType(getTagValue("fact-type", element));
            
        }
        return fact;
    }
	
    private static String getTagValue(String tag, Element element) 
    {
        NodeList nodeList = element.getElementsByTagName(tag).item(0).getChildNodes();
        Node node = (Node) nodeList.item(0);
        return node.getNodeValue();
    }
    
    public static void main(String[] args) throws TransformerException {
        String filePath = "C:\\Users\\Lakshmi\\UTD-COURSES\\SE4367-Testing\\facts(1)\\facts\\data\\facts.xml";
        File xmlFile = new File(filePath);
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder;
        try {
            dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(xmlFile);
            doc.getDocumentElement().normalize();
            
            System.out.println("Please enter a fact: ");
    		Scanner a = new Scanner(System.in);
    		String b = a.nextLine(); 
    		if(b.length() == 0 || b == null)
    		{
    			System.out.println("Please enter a fact to be added. Please start over!");
    			System.exit(0);
    		}
    		if(b.length() > 100)
    		{
    			System.out.println("Your response exceeds the limit of 100 characters. Please enter a valid input.Try again!");
    			System.exit(0);
    		}
            Element documentElement = doc.getDocumentElement();
            Element bb = doc.createElement("fact-text");
            bb.setTextContent(b);
            
            System.out.println("Please enter the name of the author: ");
    		Scanner c = new Scanner(System.in);
    		String d = a.nextLine();
            Element dd = doc.createElement("author");
            dd.setTextContent(d);
            
        	System.out.println("Please enter the fact type: ");
    		Scanner e = new Scanner(System.in);
    		String f = a.nextLine();
    		if(!f.equalsIgnoreCase("fact") && !f.equalsIgnoreCase("fallacy")) 
    		{
    			System.out.println("You must enter fact or fallacy. Please start over!");
    			System.exit(0);
    		}
            Element ee = doc.createElement("fact-type");
            ee.setTextContent(f);
            
            Element nodeElement = doc.createElement("fact");
            nodeElement.appendChild(bb);
            nodeElement.appendChild(dd);
            nodeElement.appendChild(ee);
            
            documentElement.appendChild(nodeElement);
            doc.replaceChild(documentElement, documentElement);
           
            
            System.out.println("This is the file with the changes reflected"); 
            System.out.println("Keyword: " + doc.getDocumentElement().getNodeName());
            NodeList nodeList = doc.getElementsByTagName("fact");
            
            
         
            
            // now XML is loaded as Document in memory, lets convert it to Object List
            List < Fact > factList = new ArrayList < Fact > ();

            for (int i = 0; i < nodeList.getLength(); i++) {
                factList.add(getfact(nodeList.item(i)));
            }
            
            for (Fact emp: factList) {
                System.out.println(emp.toString());
            }
            
         
        } catch (SAXException | ParserConfigurationException | IOException e1) {
            e1.printStackTrace();
        }
        	
         
		}
    }

				
		
						
    
    

	
	
    

