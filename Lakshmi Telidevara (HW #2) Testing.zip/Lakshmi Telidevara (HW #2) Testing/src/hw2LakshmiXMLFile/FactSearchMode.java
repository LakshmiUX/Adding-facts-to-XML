package hw2LakshmiXMLFile;

public class FactSearchMode {

	public static final int ALL_VAL = 0;
	public static final int AUTHOR_VAL111 = 0;
	public static final int TEXT_VAL = 0;
	public static final int TYPE_VAL111 = 0;
	public static final int AUTHOR_VAL1 = 0;
	public static final int TYPE_VAL11111 = 0;
	public static final int AUTHOR_VAL1111 = 0;
	public static final int AUTHOR_VAL11 = 0;
	public static final int AUTHOR_VAL = 0;
	public static final int TYPE_VAL1111 = 0;
	public static int TYPE_VAL11;
	public static int TYPE_VAL1;
	public static int TYPE_VAL;

}
